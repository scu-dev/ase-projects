﻿#region Using 指令

using System.Reflection;
using System.Runtime.CompilerServices;

#endregion

//程序集的常规信息是通过下列属性集
//控制的。更改这些属性值可修改
//与程序集关联的信息。
[assembly: AssemblyTitle("CSPenColor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft (Visual C++ QA)")]
[assembly: AssemblyProduct("CSPenColor")]
[assembly: AssemblyCopyright("Copyright @ Microsoft (Visual C++ QA) 2004")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//程序集的版本信息由下面四个值组成：
//
//主版本
//次版本 
//内部版本号
//修订号
//
//可以指定所有值，也可以使用“修订号”和“内部版本号”的默认值，
//方法是按如下所示使用“*”：
[assembly: AssemblyVersion("1.0.*")]
